﻿using System;
using System.Windows.Input;

namespace WpfApp1.ViewMod
{
    internal class RelayCommandBase
    {

    }
}